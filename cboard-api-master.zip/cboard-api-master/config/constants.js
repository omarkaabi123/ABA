const JWT_DEFAULT_ISSUER = 'cboard.io';

module.exports = {
  JWT_DEFAULT_ISSUER
};
